# AGENTS.md

Guidance for AI agents working on this repository.

## What this is
A single-page, Hindi-language (`lang="hi"`) portfolio for journalist Abhishek Kumar Dwivedi. It's a static site with no framework, no bundler and no npm dependencies. Deployable output is the `public/` folder as-is.

## Architecture
- `public/index.html`: all page content, section by section (hero → outlets → about → experience → work → channel → skills → education → contact → footer → project `<dialog>`). An inline SVG sprite at the top of `<body>` provides every icon (`<use href="#i-…">`).
- `public/css/styles.css`: the whole design system. Tokens are CSS custom properties in `:root` (paper/ink palette, one accent `--accent`, fonts, spacing, easing). Sections follow in page order, then motion, then responsive breakpoints (1080 / 960 / 720 / 540 px).
- `public/js/main.js`: one IIFE. Handles header scroll state and progress bar, mobile menu, nav scroll-spy, scroll reveal, work filters, project dialog (data in `projects`) and the contact form.
- `server.js`: zero-dependency Node static server for `npm start` and Replit's Run button. It returns 405 for POST on purpose; see the form notes below.
- `netlify.toml` publishes `public/`. `.replit` configures Run plus a Static Deployment from `public/`.

## Conventions
- **Content integrity:** never invent achievements, publications, dates or personal details. Only use verified content supplied by the owner. Missing information gets a clearly styled placeholder (see `.role--pending`).
- **Typography:** headings use `--font-display` (Tiro Devanagari Hindi), body uses `--font-body` (Mukta). Don't add letter-spacing to Devanagari text, because it breaks the shirorekha. Tracking is only used on Latin numerals (`.eyebrow__num`, `.skill__num`).
- **Colour:** stay with the paper/ink palette plus the single press-red accent. No gradients, glows or extra hues.
- **Motion:** animate only `transform`/`opacity`/`clip-path`. Elements get `.reveal` (scroll) or `.load-in` with `--d` (hero stagger). Everything respects `prefers-reduced-motion`. Hidden-until-revealed styles are scoped under `.js`, so content stays visible without JavaScript.
- **Images:** pre-optimised WebP files in `public/img/` at 720 w and 1200 w, used through `srcset`. Images aren't routed through a host-specific image CDN, so the site works on both Netlify and Replit. Illustrative (non-reportage) images carry a visible `प्रतीकात्मक चित्र` label.
- **Contact form:** Netlify Forms (`data-netlify="true"`, honeypot `bot-field`, fields `name`, `email`, `topic`, `message`). JS posts URL-encoded data to `/`. Any non-2xx response, as on Replit or local, shows an error with a pre-filled `mailto:` fallback. If you rename fields, keep the HTML form and the JS in sync. The select is named `topic` rather than `subject` because Netlify treats a `subject` field as the notification email subject.
- Keep edits small and in plain CSS/JS. Don't reintroduce Tailwind CDN or Font Awesome. They were removed for performance and to clear console warnings.

## Non-obvious decisions
- The original "6+ media institutions" stat was dropped because only five organisations are named in the content.
- The Awards and Video sections were left out because no verified material exists yet. See README "Suggested next additions".
- English machine-translation artefacts from the original (for example "और" replacing "and" inside English text) were corrected, and the project dialog copy was translated to Hindi to match the rest of the site.
