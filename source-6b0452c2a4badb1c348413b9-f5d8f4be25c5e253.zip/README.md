# अभिषेक कुमार द्विवेदी — Journalist Portfolio

The personal portfolio of Abhishek Kumar Dwivedi, a Bhopal-based journalist and digital media creator: copy editor at Prasar Bharati – SHABD (DD News), previously with Vistaar News, Dainik Bhaskar Digital and Time8 Madhya Pradesh. The site is in Hindi and has an editorial, newspaper-inspired design.

## What's on the page

- **Hero:** name, role, short bio, work-samples and contact calls to action, portrait, key facts.
- **Newsroom strip:** the organisations he has worked with.
- **01 Profile:** professional introduction, digital identity, four areas of work.
- **02 Experience:** career timeline. The News Bharat entry is a placeholder until its details are added.
- **03 Work:** link to the Google Drive archive, category filters, four story cards that open a detail dialog.
- **Explore with Abhi:** the digital channel, plus Instagram and blog links.
- **04 Skills, 05 Education.**
- **06 Contact:** contact details, social links and a working contact form.

## Technology

- Static **HTML, CSS and vanilla JavaScript**. There's no framework and no build step.
- Fonts: **Tiro Devanagari Hindi** for headings and **Mukta** for body text, both from Google Fonts.
- Icons are an inline SVG sprite at the top of `index.html`.
- The contact form uses **Netlify Forms** with a honeypot. On hosts without form handling (such as Replit), the form offers a pre-filled email link instead.
- Images are pre-optimised WebP files in `public/img/`, in 720 px and 1200 px sizes.

## Project structure

```
public/            ← the deployable site
  index.html       ← all content and markup
  css/styles.css   ← design system (colours, type, layout, motion)
  js/main.js       ← menu, scroll reveal, filters, project dialog, form
  img/             ← optimised images
  404.html, favicon.svg
server.js          ← zero-dependency static server (local preview / Replit Run)
netlify.toml       ← Netlify: publish /public, headers
.replit            ← Replit: run command + static deployment config
```

## Run locally

Requires Node.js 18 or newer. There's nothing to install.

```bash
npm start
# → http://localhost:3000
```

You can also open `public/index.html` directly or serve `public/` with any static server.

## Deploy

**Netlify:** already configured. `netlify.toml` publishes `public/` with no build command. Contact form submissions show up in the Netlify dashboard under Forms.

**Replit:**
1. Import the repository into a Replit app. `.replit` is already set up.
2. Press **Run**. This starts `npm start` on port 3000 for the preview.
3. Choose **Deploy → Static**. The config sets `publicDir = "public"`, so you don't need a build command or environment variables.
4. Contact form submissions aren't stored on Replit. Visitors get a pre-filled email link to `connectabhishekdwivedi@gmail.com` instead.

## Editing content

All text lives in `public/index.html`. Project dialog text is in the `projects` object in `public/js/main.js`. Only verified information about the journalist belongs on the site. Mark anything you're unsure of as a placeholder rather than guessing.

## Suggested next additions (when verified material is available)

- A higher-resolution portrait. The current one is 288 × 288 px.
- Role details and dates for News Bharat.
- Links to specific published articles or video reports, and YouTube links for Explore with Abhi.
- An "Awards & recognition" section. It was left out because no awards are documented yet.
