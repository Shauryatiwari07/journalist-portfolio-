// Zero-dependency static file server for local preview and Replit's "Run" button.
// Serves the ./public folder. Usage: `npm start` (PORT defaults to 3000).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function send(res, status, file) {
  const type = TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream';
  const cache = file.endsWith('.html') ? 'no-cache' : 'public, max-age=3600';
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': cache, 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    // The contact form posts to Netlify Forms in production. Anywhere else, the
    // page falls back to a pre-filled email link when it receives this response.
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end();
  }

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch {
    res.writeHead(400);
    return res.end();
  }

  let file = path.normalize(path.join(ROOT, pathname));
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    return res.end();
  }

  fs.stat(file, (err, stat) => {
    if (!err && stat.isDirectory()) file = path.join(file, 'index.html');
    fs.stat(file, (err2, stat2) => {
      if (!err2 && stat2.isFile()) return send(res, 200, file);
      // Extensionless "pretty" URLs, e.g. /about -> /about.html
      const html = `${file}.html`;
      fs.stat(html, (err3, stat3) => {
        if (!err3 && stat3.isFile()) return send(res, 200, html);
        return send(res, 404, path.join(ROOT, '404.html'));
      });
    });
  });
});

server.listen(PORT, HOST, () => {
  console.log(`Portfolio running at http://localhost:${PORT}`);
});
