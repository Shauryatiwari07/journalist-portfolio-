/* Abhishek Kumar Dwivedi — portfolio interactions. Vanilla JS, no dependencies. */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Footer year ---------- */
  const year = $('#year');
  if (year) year.textContent = String(new Date().getFullYear());

  /* ---------- Header state + reading progress ---------- */
  const header = $('.site-header');
  const bar = $('.progress span');
  let ticking = false;
  const onScroll = () => {
    const y = window.scrollY;
    header.classList.toggle('is-scrolled', y > 12);
    const max = document.documentElement.scrollHeight - window.innerHeight;
    if (bar) bar.style.transform = `scaleX(${max > 0 ? Math.min(y / max, 1) : 0})`;
    ticking = false;
  };
  window.addEventListener('scroll', () => {
    if (!ticking) { requestAnimationFrame(onScroll); ticking = true; }
  }, { passive: true });
  onScroll();

  /* ---------- Mobile navigation ---------- */
  const toggle = $('#nav-toggle');
  const navList = $('#nav-list');
  const setMenu = (open) => {
    navList.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'मेनू बंद करें' : 'मेनू खोलें');
  };
  toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  $$('.nav__link', navList).forEach((a) => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && navList.classList.contains('is-open')) { setMenu(false); toggle.focus(); }
  });
  document.addEventListener('click', (e) => {
    if (navList.classList.contains('is-open') && !header.contains(e.target)) setMenu(false);
  });
  window.matchMedia('(min-width: 961px)').addEventListener('change', (e) => { if (e.matches) setMenu(false); });

  /* ---------- Active section in nav ---------- */
  const navLinks = $$('.nav__link:not(.nav__cta)');
  const sectionIds = navLinks.map((a) => a.getAttribute('href').slice(1));
  const sections = sectionIds.map((id) => document.getElementById(id)).filter(Boolean);
  if ('IntersectionObserver' in window && sections.length) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinks.forEach((a) => {
          const active = a.getAttribute('href') === `#${entry.target.id}`;
          a.classList.toggle('is-active', active);
          if (active) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach((s) => spy.observe(s));
  }

  /* ---------- Scroll reveal (staggered within each group) ---------- */
  const reveals = $$('.reveal');
  const groups = new Map();
  reveals.forEach((el) => {
    const parent = el.parentElement;
    const i = groups.get(parent) || 0;
    el.style.setProperty('--stagger', `${Math.min(i, 5) * 80}ms`);
    groups.set(parent, i + 1);
  });
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    reveals.forEach((el) => io.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add('is-visible'));
  }

  /* ---------- Work filters ---------- */
  const grid = $('#stories');
  const stories = $$('.story', grid);
  const filters = $$('.filter');
  const status = $('#filter-status');
  const applyFilter = (value) => {
    let count = 0;
    stories.forEach((card) => {
      const show = value === 'all' || card.dataset.category === value;
      card.hidden = !show;
      if (show) { count += 1; card.classList.add('is-visible'); }
    });
    grid.dataset.count = String(count);
    if (status) status.textContent = `${count} परियोजनाएँ दिखाई जा रही हैं`;
  };
  filters.forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.classList.contains('is-active')) return;
      filters.forEach((b) => { b.classList.toggle('is-active', b === btn); b.setAttribute('aria-pressed', String(b === btn)); });
      if (reduceMotion) { applyFilter(btn.dataset.filter); return; }
      grid.classList.add('is-switching');
      setTimeout(() => { applyFilter(btn.dataset.filter); grid.classList.remove('is-switching'); }, 230);
    });
  });

  /* ---------- Project details dialog ---------- */
  const projects = {
    jazba: {
      category: 'डॉक्यूमेंट्री फ़िल्म · कार्य प्रगति पर',
      title: 'जज़्बा: आवाज़ की जीत',
      subtitle: 'मध्य प्रदेश के दृष्टिबाधित क्रिकेट खिलाड़ियों पर केंद्रित',
      description: 'एक संवेदनशील डॉक्यूमेंट्री, जो दिखाती है कि आवाज़, अंतर्ज्ञान और अटूट संकल्प किस तरह मध्य प्रदेश के दृष्टिबाधित क्रिकेट खिलाड़ियों को राष्ट्रीय और अंतरराष्ट्रीय स्तर पर प्रतिस्पर्धा करने की ताक़त देते हैं। सोनू गोलकर, ओमप्रकाश और प्रिया कीर के साथ आत्मीय साक्षात्कारों के माध्यम से फ़िल्म उनके मैदानी कौशल और निजी यात्राओं — दोनों को दर्ज करती है।',
      highlights: [
        'सोनू गोलकर, ओमप्रकाश और प्रिया कीर की विस्तृत प्रोफ़ाइल।',
        'ब्लाइंड क्रिकेट की बारीकियाँ और ध्वनि-आधारित सजगता की भूमिका।',
        'मध्य प्रदेश में सशक्त खेल ढाँचे और संस्थागत मान्यता की आवश्यकता पर ज़ोर।',
      ],
      topic: 'डॉक्यूमेंट्री एवं वीडियो निर्माण',
    },
    'mlm-book': {
      category: 'नॉन-फ़िक्शन पुस्तक · कार्य प्रगति पर',
      title: 'उपभोक्ता धोखाधड़ी एवं MLM योजनाओं पर खोजपरक पुस्तक',
      subtitle: 'तथ्यपरक शोध, योजनाओं की पड़ताल एवं जन-जागरूकता',
      description: 'सक्रिय शोध और लेखन के चरण में यह खोजपरक नॉन-फ़िक्शन कृति बताती है कि भ्रामक मल्टी-लेवल मार्केटिंग (MLM) नेटवर्क और धोखाधड़ी वाली वित्तीय योजनाएँ अर्ध-शहरी और शहरी भारत में कैसे काम करती हैं, और नागरिकों को स्पष्ट चेतावनी-संकेतों की सूची तथा क़ानूनी उपाय बताती है।',
      highlights: [
        'सत्यापित उपभोक्ता शिकायतों, नियामकीय दिशानिर्देशों और वित्तीय आँकड़ों पर आधारित।',
        'वैध डायरेक्ट सेलिंग और अवैध पिरामिड व पोंज़ी जाल के बीच अंतर स्पष्ट करती है।',
        'विद्यार्थियों, परिवारों और पहली बार निवेश करने वालों के लिए सरल पुस्तिका के रूप में तैयार।',
      ],
      topic: 'प्रकाशन एवं नॉन-फ़िक्शन पुस्तक',
    },
    'explore-abhi': {
      category: 'डिजिटल मीडिया चैनल',
      title: 'Explore with Abhi — यात्रा एवं जन-जागरूकता वीडियो',
      subtitle: 'भोपाल, कश्मीर, दिल्ली और राजस्थान का दस्तावेज़ीकरण',
      description: 'यात्रा-गाइड और नागरिक व सांस्कृतिक जागरूकता को जोड़ने वाली डिजिटल स्टोरीटेलिंग पहल — भोपाल की झीलों और जयपुर की विरासत गलियों से लेकर श्रीनगर, सोनमर्ग, पहलगाम और जम्मू की घाटियों तथा दिल्ली तक।',
      highlights: [
        'व्यावहारिक यात्रा-योजना और सांस्कृतिक संदर्भ के साथ ज़मीनी यात्रा गाइड।',
        'स्थानीय कारीगरों, विरासत संरक्षण और नागरिक जीवन पर केंद्रित जन-जागरूकता खंड।',
        'YouTube, Blogger और Instagram (@Abhi_shek_official_) पर एकरूप दृश्य पहचान।',
      ],
      topic: 'Explore with Abhi — यात्रा / ब्रांड सहयोग',
    },
    'ground-reports': {
      category: 'पत्रकारिता एवं सांस्कृतिक कवरेज',
      title: 'मध्य प्रदेश की प्रशासनिक एवं भोपाल की सांस्कृतिक कवरेज',
      subtitle: 'नीति एवं विरासत पर तथ्यपरक रिपोर्टिंग',
      description: 'मध्य प्रदेश में प्रशासनिक निर्णयों, कृषि उपार्जन और शिक्षा नीति में बदलावों पर क्षेत्रीय पत्रकारिता — साथ में भोपाल की प्रमुख प्रदर्शनियों और उत्सवों की सांस्कृतिक कवरेज।',
      highlights: [
        'प्राथमिक स्रोतों से सत्यापन और आधिकारिक प्रशासनिक संदर्भों का सख़्ती से पालन।',
        'इंदिरा गांधी राष्ट्रीय मानव संग्रहालय (IGRMS) पर विशेष सांस्कृतिक फ़ीचर।',
        'भोजपाल महोत्सव मेले से स्थानीय परंपराओं और व्यापार पर ग्राउंड रिपोर्टिंग।',
      ],
      topic: 'पत्रकारिता / खोजपरक स्टोरी',
    },
  };

  const modal = $('#project-modal');
  const topicSelect = $('#topic');
  let lastTrigger = null;
  let currentTopic = '';

  const openProject = (key, trigger) => {
    const data = projects[key];
    if (!data || !modal) return;
    lastTrigger = trigger || null;
    currentTopic = data.topic;
    $('#modal-category').textContent = data.category;
    $('#modal-title').textContent = data.title;
    $('#modal-subtitle').textContent = data.subtitle;
    $('#modal-description').textContent = data.description;
    const list = $('#modal-highlights');
    list.replaceChildren(...data.highlights.map((text) => {
      const li = document.createElement('li');
      li.innerHTML = '<svg class="icon" aria-hidden="true"><use href="#i-check"/></svg>';
      const span = document.createElement('span');
      span.textContent = text;
      li.appendChild(span);
      return li;
    }));
    document.documentElement.classList.add('modal-open');
    modal.showModal();
  };

  const closeProject = () => {
    if (!modal.open) return;
    const finish = () => {
      modal.classList.remove('is-closing');
      modal.close();
    };
    if (reduceMotion) { finish(); return; }
    modal.classList.add('is-closing');
    setTimeout(finish, 210);
  };

  if (modal) {
    $$('.story__link').forEach((btn) => btn.addEventListener('click', () => openProject(btn.dataset.project, btn)));
    $$('[data-close]', modal).forEach((btn) => btn.addEventListener('click', closeProject));
    modal.addEventListener('click', (e) => { if (e.target === modal) closeProject(); });
    modal.addEventListener('cancel', (e) => { e.preventDefault(); closeProject(); });
    modal.addEventListener('close', () => {
      document.documentElement.classList.remove('modal-open');
      if (lastTrigger) lastTrigger.focus({ preventScroll: true });
    });
    $('#modal-ask').addEventListener('click', (e) => {
      e.preventDefault();
      if (topicSelect && currentTopic) topicSelect.value = currentTopic;
      lastTrigger = null;
      modal.classList.remove('is-closing');
      modal.close();
      document.getElementById('contact').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
      setTimeout(() => $('#name').focus({ preventScroll: true }), reduceMotion ? 0 : 700);
    });
  }

  /* ---------- Contact form (Netlify Forms, with an email fallback) ---------- */
  const form = $('#contact-form');
  if (form) {
    const submit = $('#form-submit');
    const label = $('.btn__label', submit);
    const statusBox = $('#form-status');
    const EMAIL = 'connectabhishekdwivedi@gmail.com';
    const fields = {
      name: { el: $('#name'), msg: 'कृपया अपना नाम लिखें।' },
      email: { el: $('#email'), msg: 'कृपया एक मान्य ईमेल पता लिखें।' },
      message: { el: $('#message'), msg: 'कृपया अपना संदेश लिखें।' },
    };

    const validateField = (key) => {
      const { el, msg } = fields[key];
      const value = el.value.trim();
      const ok = key === 'email' ? /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) : value.length > 1;
      const error = $(`#${key}-error`);
      el.closest('.field').classList.toggle('has-error', !ok);
      el.setAttribute('aria-invalid', String(!ok));
      if (ok) { error.textContent = ''; el.removeAttribute('aria-describedby'); }
      else { error.textContent = msg; el.setAttribute('aria-describedby', `${key}-error`); }
      return ok;
    };

    Object.keys(fields).forEach((key) => {
      const { el } = fields[key];
      el.addEventListener('blur', () => { if (el.value.trim()) validateField(key); });
      el.addEventListener('input', () => { if (el.closest('.field').classList.contains('has-error')) validateField(key); });
    });

    const showStatus = (type, html) => {
      statusBox.className = `form__status is-${type}`;
      statusBox.innerHTML = html;
      statusBox.hidden = false;
    };

    const mailtoLink = () => {
      const subject = `${fields.name.el.value.trim()} — ${topicSelect.value}`;
      const body = `${fields.message.el.value.trim()}\n\n— ${fields.name.el.value.trim()} (${fields.email.el.value.trim()})`;
      return `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    };

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const valid = Object.keys(fields).map(validateField).every(Boolean);
      if (!valid) {
        const firstBad = Object.values(fields).find(({ el }) => el.getAttribute('aria-invalid') === 'true');
        if (firstBad) firstBad.el.focus();
        return;
      }

      submit.disabled = true;
      submit.classList.add('is-loading');
      label.textContent = 'भेजा जा रहा है';
      statusBox.hidden = true;

      try {
        const res = await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(new FormData(form)).toString(),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const name = fields.name.el.value.trim();
        showStatus('success', '<strong>संदेश प्राप्त हुआ।</strong><span></span>');
        $('span', statusBox).textContent = `धन्यवाद, ${name}! आपका संदेश मिल गया है — अभिषेक द्विवेदी जल्द ही आपसे संपर्क करेंगे।`;
        form.reset();
      } catch (err) {
        showStatus('error', `<strong>संदेश अभी नहीं भेजा जा सका।</strong>कृपया कुछ देर बाद पुनः प्रयास करें, या <a href="${mailtoLink()}">सीधे ईमेल भेजें</a>।`);
      } finally {
        submit.disabled = false;
        submit.classList.remove('is-loading');
        label.textContent = 'संदेश भेजें';
      }
    });
  }
})();
